TeVii BDA 1.0
============

This plugin is for the TeVii PC-DVB tuners with BDA-drivers.
It was originally as WinLIRC 0.6.5 mod and now rewriten as plugin for WinLIRC 0.8.6+.

In config need select tuner device number (if installed many tuners).

Supported Remotes
=================

Any China-made remotes :)

Links
=====

TeVii PC-DVB tuners - http://www.tevii.com

WinLIRC 0.6.5 for TeVii BDA - http://crazycat69.narod.ru/sattelite/WinLIRC/WinLIRC-TVBDA.rar
WinLIRC 0.6.5 for TeVii BDA sources - http://crazycat69.narod.ru/sattelite/WinLIRC/WinLIRC-TVBDA-src.rar

Contact
=======

If you want to contact me about this plugin mail me at crazycat69@narod.ru. Any problems
please leave bug reports on sourceforge so I can help resolve them.
