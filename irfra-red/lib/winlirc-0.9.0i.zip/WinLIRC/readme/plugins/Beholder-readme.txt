Beholder 1.0
============

This plugin is for the Russian Beholder tv tuners. It was originally written by the author of 
http://code.google.com/p/winlirc-beholder/ But I changed it to support more remote controls,
instead of just the one remote that he had. But lacking a beholder receiver I couldn't test it,
so PETY3bI kindly tested and debugged the plugin for me, fixing a critical issue.

Supported Remotes
=================

NEC, JVC, Panasonic, Samsung, Sony SIRC-12, SIRC-15 and SIRC-20.
Might work with others too.

Links
=====

http://www.beholder.ru/bb/viewtopic.php?t=12396
http://code.google.com/p/winlirc-beholder/


