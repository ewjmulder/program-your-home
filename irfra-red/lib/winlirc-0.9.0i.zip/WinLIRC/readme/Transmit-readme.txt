WinLIRC

Please see

        http://winlirc.sourceforge.net

for information regarding this program.


transmit.exe was written by Scott Baily <baily@users.sourceforge.net>

usage: transmit remotename codename reps
reps is an optional number of times to repeat the code (default=0).

It is public domain, since the code is trivial.
Mainly it is an example of how to send commands to winLIRC
from your application.

transmit.cpp is the source code for transmit.exe
It uses only windows API functions so you should be able to
compile it with any win32 C++ compiler.  Just be should to include
the appropriate header file (#include <windows.h>).

To compile transmit.exe with MS VC++, create a "simple win32 application"
then use this code as the main program.


If you're not interested in modifying the program the only interesting files are:

winlirc.exe

transmit.exe (optional) commandline program to tell winlirc to transmit a code

*.cf (configuration files for remotes)
