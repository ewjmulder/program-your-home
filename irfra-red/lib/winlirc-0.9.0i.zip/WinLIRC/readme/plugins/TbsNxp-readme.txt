TBS-NXP BDA 1.0
============

This plugin is for the SAA7160-based TBS PC-DVB tuners with BDA-drivers.

In config need select tuner device number (if installed many tuners) and RC type.

Supported Remotes
=================

RC5, RC6, NEC-encoded.

Links
=====

TBS PC-DVB tuners - http://www.tbsdtv.com

Contact
=======

If you want to contact me about this plugin mail me at crazycat69@narod.ru. Any problems
please leave bug reports on sourceforge so I can help resolve them.
