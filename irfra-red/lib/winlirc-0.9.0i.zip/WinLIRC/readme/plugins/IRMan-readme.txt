IRMan 1.2
=========

- Improved hardware compatability.

IRMan 1.1
=========

- Real IRMan devices require power on the RTS and DTS pins to work. This was previously missing.

IRMan 1.0 - by Ian Curtis
=========

This is a plugin for IRMan and compatable receivers. I've only tested this with a IRToy USB receiver
since it is has an IRMan compatable mode and installs itself as a serial device on a com port, but there
is no reason why it shouldn't work with a real IRMan. There is also a good chance an IRMan receiver will 
work with a serial -> USB cable.

