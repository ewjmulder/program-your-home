RawCodes 1.0
============

This is a simple tool to see the raw data coming from the plugin. Not all plugins will work with this program
since some don't export any raw data. WinLIRC might need to be closed for this to work, depending on the plugin.
Press the any key to exit, if you can find it :)

Installation
============

Simply copy the .exe to the same folder as WinLIRC.

Setup
=====

The graphing tools loads the same .ini file as WinLIRC. So make sure you chosen plugin is setup correctly
in WinLIRC. Close WinLIRC and then open the graphing tool. Then press buttons on your remote !