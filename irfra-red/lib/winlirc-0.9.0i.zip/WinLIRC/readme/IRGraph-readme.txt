irGraph 1.0
===========

This is a simple graphing tool for plugins that support receiving mode2 data (raw timing info). This
version requires WinLIRC 0.8.6b. It's useful to check that you have your receiver setup correctly and that
you are getting good reception. It's easy to see if you signals aren't being received properly when the
data is drawn. You might need to close WinLIRC to get this to work (depending on your receiver).

Installation
============

Simply copy the .exe to the same folder as WinLIRC.

Setup
=====

The graphing tools loads the same .ini file as WinLIRC. So make sure you chosen plugin is setup correctly
in WinLIRC. Close WinLIRC and then open the graphing tool. Then press buttons on your remote !