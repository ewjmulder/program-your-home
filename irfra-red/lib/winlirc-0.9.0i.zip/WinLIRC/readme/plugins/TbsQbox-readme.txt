TBS-QBOX BDA 1.0
============

This plugin is for the TBS PC-DVB USB tuners with BDA-drivers.

In config need select tuner device number (if installed many tuners).

Supported Remotes
=================

NEC-encoded.

Links
=====

TBS PC-DVB tuners - http://www.tbsdtv.com

Contact
=======

If you want to contact me about this plugin mail me at crazycat69@narod.ru. Any problems
please leave bug reports on sourceforge so I can help resolve them.
