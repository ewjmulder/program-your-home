RawMessages 1.0
===============

This is a simple winlirc client example, it's also useful to see what key presses WinLIRC is broadcasting
though the server.


Setup
=====

Load WinLIRC, if the icon turns green you should see the names of the keys being pressed on the console.
Press the any key to exit !