See:
https://github.com/pborsutzki/winlirc-hauppauge/blob/master/README.md
