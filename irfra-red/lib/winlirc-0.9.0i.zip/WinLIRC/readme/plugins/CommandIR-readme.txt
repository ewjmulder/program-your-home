CommandIR 1.0
=============

Version 1 for the CommandIR hardware for windows. Previously this receiver only worked under Linux,
but now windows users can use it too :) To select different transmitters you'll need to send
SET_TRANSMITTERS to WinLirc. There is no external tool to do this yet, hopefully a Windows equivilant
of IRSend will appear in the future. But it shouldn't be too hard to script something.

Setup
=====

- Make sure you have installed the drivers from the CommandIR website
- For new receivers you'll need to flash them to the latest firmware. As of writing the tool to do this
  is unreleased but there is a windows version.

Website
=======

http://www.commandir.com