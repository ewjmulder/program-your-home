Technisat WDM 1.0
=================

This plugin is for the Technisat PC-DVB tuners with integrated IR RC support and NDIS(WDM)-drivers.
Now supported SkyStar USB HD (USB2.0), SkyStar 2 eXpress HD (PCI-E).

In config need select tuner device number (if installed many tuners).

Supported Remotes
=================

RC5-encoded.

Links
=====

Technisat PC-DVB tuners - http://www.technisat.com

Contact
=======

If you want to contact me about this plugin mail me at crazycat69@narod.ru. Any problems
please leave bug reports on sourceforge so I can help resolve them.

Config File
==========

http://winlirc.sourceforge.net/remotes/Technisat/Technisat_SkystarHD
