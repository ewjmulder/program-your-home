Technotrend BDA 1.0
============

This plugin is for the Technotrend PC-DVB tuners with BDA-drivers and ODM's like Technisat SkyStar HD;
Satelco EasyWatch USB; Pinnacle 400e, 450e, 452e.
It was originally as WinLIRC 0.6.5 mod and now rewriten as plugin for WinLIRC 0.8.6+.

In config need select tuners type and device number (if installed many tuners).

Supported Remotes
=================

Any RC5,6 remotes.

Links
=====

Technotrend PC-DVB tuners - http://www.tt-pc.com/2762/PRODUCTS_for_PC.html
Satelco EasyWatch USB - http://www.satelco.de/htm/shop/easywatch_usb/index.htm
Pinnacle PCTV 400e, 450e, 452e - http://www.pctvsystems.com/Products/ProductsEuropeAsia/Satelliteproducts/tabid/143/language/en-GB/Default.aspx

WinLIRC 0.6.5 for Technotrend BDA - http://crazycat69.narod.ru/sattelite/WinLIRC/WinLIRC-TTBDA.rar
WinLIRC 0.6.5 for Technotrend BDA sources - http://crazycat69.narod.ru/sattelite/WinLIRC/WinLIRC-TTBDA-src.rar

Contact
=======

If you want to contact me about this plugin mail me at crazycat69@narod.ru. Any problems
please leave bug reports on sourceforge so I can help resolve them.
