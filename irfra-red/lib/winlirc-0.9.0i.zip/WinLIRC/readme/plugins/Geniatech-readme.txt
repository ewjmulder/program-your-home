Geniatech BDA 1.0
===============

This plugin is for the Geniatech-designed PC-DVB tuners with BDA-drivers.

Always used first compatible device in system !

Supported Remotes
================

RC5 remotes.

Links
=====

Geniatech PC-DVB tuners - http://www.geniatech.com/tv-tuner.asp
SatTrade X3Mtv PC-DVB tuners - http://www.sattrade.ru
GOTVIEW SatelliteHD DVB-S2 - http://www.gotview.ru/v2/sat.html

Contact
=======

If you want to contact me about this plugin mail me at crazycat69@narod.ru. Any problems
please leave bug reports on sourceforge so I can help resolve them.
